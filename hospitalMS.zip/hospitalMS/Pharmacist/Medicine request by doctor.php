<html>
<head>

<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
table {
  border-collapse: collapse;
  border-spacing: 0;
  width: 100%;
  border: 1px solid #ddd;
}

th, td {
  text-align: center;
  padding: 16px;
}

th:first-child, td:first-child {
  text-align: left;
}

tr:nth-child(even) {
  background-color: #f2f2f2
}

.fa-check {
  color: green;
}

.fa-remove {
  color: red;
}
</style>
</head>
<body>

<h2>Medicine request by doctor</h2>

<table>
  <tr>
    <th style="width:50%">Medicine </th>
    <th>Tablet</th>
    <th>Capsul</th>
  </tr>
  <tr>
    <td>Sample text</td>
    <td><input type="checkbox">T</input></td>
    <td><input type="checkbox">C</input></td>
  </tr>
  <tr>
    <td>Sample text</td>
	
    <td><input type="checkbox">T</input></td>
    <td><input type="checkbox">C</input></td>
  </tr>
  <tr>
    <td>Sample text</td>
    <td><input type="checkbox">T</input></td>
    <td><input type="checkbox">C</input></td>
  </tr>
  <tr>
    <td>Sample text</td>
    <td><input type="checkbox">T</input></td>
    <td> <input type="checkbox">C</input></td>
  </tr>
  <tr>
    <td>Sample text</td>
    <td> <input type="checkbox">T</input></td>
    <td> <input type="checkbox">C</input></td>
  </tr>
</table>

</body>
</html>