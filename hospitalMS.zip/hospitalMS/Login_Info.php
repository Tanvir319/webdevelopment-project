<html lang="en">
<head>
  <title>LOGIN INFO</title>
  <link rel="stylesheet" type="text/css" href="/hospitalMS/Assets/Login_Info.css" media="screen"/>
</head>
<body background="/hospitalMS/login.png">

    <div class="info_title">
        <h1>LOGIN FACADE </h1>
        <h2>(Please Select User Type) </h2>
    </div>

    <div class="user_info">
        <table border="10">
            <tr>
                <td class="hover_data">
                    <a href="./Admin/AdminFacade.php" class="hover-2">ADMIN</a>
                </td>
            </tr>
            <tr>
                <td class="hover_data">
                    <a href="./Patient/PatientFacade.php" class="hover-2">PATIENT</a>
                </td>
            </tr>

            <tr>
                <td class="hover_data">
                    <a href="/hospitalMS/Pharmacist/form.html" class="hover-2">PHARMACIST</a>
                </td>
            </tr>

        </table>
    </div>
    <br> <br><br>
    <hr>
    <footer>
        <center>
            <p>Copyright by owner</p>
        </center>
    </footer>
</body>

</html>